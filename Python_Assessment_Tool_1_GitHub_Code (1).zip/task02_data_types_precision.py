# TASK 2: Data Types, Operators and Floating-Point Precision

from decimal import Decimal

print("Division:", 7 / 2)
print("Floor division:", 7 // 2)
print("Modulus:", 7 % 2)
print("Unary and floor division:", -(-7) // 2)

print("\nFloating-point precision:")
print("0.1 + 0.2 =", 0.1 + 0.2)
print("0.1 + 0.2 == 0.3:", 0.1 + 0.2 == 0.3)

print("\nUsing Decimal:")
a = Decimal("0.1")
b = Decimal("0.2")
c = Decimal("0.3")
print("0.1 + 0.2 =", a + b)
print("Decimal equality:", a + b == c)

# Compare totals for a number of payments
number_of_payments = int(input("\nEnter number of payments: "))
float_total = 0.0
decimal_total = Decimal("0.00")

for _ in range(number_of_payments):
    float_total += 33.40
    decimal_total += Decimal("33.40")

print(f"Float total: Rs.{float_total:.2f}")
print(f"Decimal total: Rs.{decimal_total:.2f}")
