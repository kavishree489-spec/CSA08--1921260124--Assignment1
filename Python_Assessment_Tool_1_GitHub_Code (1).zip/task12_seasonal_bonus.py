# TASK 12: Revised Design - Seasonal Rate and Ten-Day Bonus

from decimal import Decimal, ROUND_HALF_UP

BASE_FAT = Decimal("3.50")
BASE_SNF = Decimal("8.50")
ORIGINAL_BASE_RATE = Decimal("30.00")
ORIGINAL_FAT_STEP = Decimal("0.40")
SEASONAL_BASE_RATE = Decimal("32.00")
SEASONAL_FAT_STEP = Decimal("0.45")
SNF_STEP = Decimal("0.30")
BONUS_PER_LITRE = Decimal("0.50")
BONUS_LIMIT = Decimal("500")
CENT = Decimal("0.01")

def rate_per_litre(fat, snf, season):
    if season.lower() == "april-june":
        base_rate = SEASONAL_BASE_RATE
        fat_adjustment = SEASONAL_FAT_STEP
    elif season.lower() == "original":
        base_rate = ORIGINAL_BASE_RATE
        fat_adjustment = ORIGINAL_FAT_STEP
    else:
        raise ValueError("Season must be 'original' or 'april-june'.")

    # The assessment example uses the nearest whole step.
    fat_steps = round((fat - BASE_FAT) / Decimal("0.10"))
    snf_steps = round((snf - BASE_SNF) / Decimal("0.10"))

    return (
        base_rate
        + Decimal(fat_steps) * fat_adjustment
        + Decimal(snf_steps) * SNF_STEP
    )

def payout(quantity, fat, snf, season):
    rate = rate_per_litre(fat, snf, season)
    amount = quantity * rate
    return amount.quantize(CENT, rounding=ROUND_HALF_UP)

def bonus(total_litres):
    if total_litres > BONUS_LIMIT:
        return (total_litres * BONUS_PER_LITRE).quantize(
            CENT, rounding=ROUND_HALF_UP
        )
    return Decimal("0.00")

def main():
    season = input("Enter season (original/April-June): ").strip()
    total_litres = Decimal("0")
    total_payment = Decimal("0.00")

    for day in range(1, 11):
        print(f"\nDay {day}")
        try:
            quantity = Decimal(input("Enter litres: "))
            fat = Decimal(input("Enter fat percentage (2 decimals): "))
            snf = Decimal(input("Enter SNF percentage (2 decimals): "))
            if quantity <= 0:
                print("Quantity must be greater than zero.")
                continue

            payment = payout(quantity, fat, snf, season)
            total_litres += quantity
            total_payment += payment
            print(f"Rate per litre: Rs.{rate_per_litre(fat, snf, season):.2f}")
            print(f"Payment: Rs.{payment:.2f}")

        except (ValueError, ArithmeticError) as error:
            print("Invalid input:", error)

    extra_bonus = bonus(total_litres)
    final_total = (total_payment + extra_bonus).quantize(
        CENT, rounding=ROUND_HALF_UP
    )

    print(f"\nTotal litres: {total_litres}")
    print(f"Ten-day milk payment: Rs.{total_payment:.2f}")
    print(f"Bonus: Rs.{extra_bonus:.2f}")
    print(f"Final amount: Rs.{final_total:.2f}")

if __name__ == "__main__":
    main()
