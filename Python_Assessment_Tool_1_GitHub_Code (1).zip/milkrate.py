# TASK 7: Reusable module for milk rate and payment calculations

BASE_RATE = 30.00
BASE_FAT = 3.5
BASE_SNF = 8.5
FAT_ADJUSTMENT = 0.40
SNF_ADJUSTMENT = 0.30

def valid_input(quantity, fat, snf):
    return quantity > 0 and 2.0 <= fat <= 7.0 and 0.0 <= snf <= 12.0

def rate_per_litre(fat, snf):
    fat_steps = (fat - BASE_FAT) / 0.1
    snf_steps = (snf - BASE_SNF) / 0.1
    return BASE_RATE + fat_steps * FAT_ADJUSTMENT + snf_steps * SNF_ADJUSTMENT

def payout(quantity, fat, snf):
    return quantity * rate_per_litre(fat, snf)

def ten_day_total(payments):
    return sum(payments)

if __name__ == "__main__":
    print("Milk rate module test")
    print(f"Rate: Rs.{rate_per_litre(4.2, 8.7):.2f}")
    print(f"Payment: Rs.{payout(10, 4.2, 8.7):.2f}")
