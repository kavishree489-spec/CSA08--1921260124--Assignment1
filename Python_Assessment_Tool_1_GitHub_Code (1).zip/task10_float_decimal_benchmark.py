# TASK 10: Compare Float and Decimal Execution

from decimal import Decimal
from time import perf_counter

COUNTS = [300, 6000, 150000]
PAYMENT_FLOAT = 33.40
PAYMENT_DECIMAL = Decimal("33.40")

for count in COUNTS:
    start = perf_counter()
    float_total = 0.0
    for _ in range(count):
        float_total += PAYMENT_FLOAT
    float_time = perf_counter() - start

    start = perf_counter()
    decimal_total = Decimal("0.00")
    for _ in range(count):
        decimal_total += PAYMENT_DECIMAL
    decimal_time = perf_counter() - start

    expected = Decimal(count) * PAYMENT_DECIMAL
    print(f"\nNumber of payments: {count}")
    print(f"Expected total: Rs.{expected:.2f}")
    print(f"Float total: Rs.{float_total:.2f}")
    print(f"Decimal total: Rs.{decimal_total:.2f}")
    print(f"Float time: {float_time:.6f} seconds")
    print(f"Decimal time: {decimal_time:.6f} seconds")
