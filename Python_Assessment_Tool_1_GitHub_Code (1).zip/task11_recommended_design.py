# TASK 11: Recommended Design
# Uses Decimal, reusable functions, validation and a running total.

from decimal import Decimal, ROUND_HALF_UP

BASE_RATE = Decimal("30.00")
BASE_FAT = Decimal("3.5")
BASE_SNF = Decimal("8.5")
FAT_ADJUSTMENT = Decimal("0.40")
SNF_ADJUSTMENT = Decimal("0.30")
CENT = Decimal("0.01")

def calculate_rate(fat, snf):
    fat_steps = (fat - BASE_FAT) / Decimal("0.1")
    snf_steps = (snf - BASE_SNF) / Decimal("0.1")
    return BASE_RATE + fat_steps * FAT_ADJUSTMENT + snf_steps * SNF_ADJUSTMENT

def calculate_payment(quantity, fat, snf):
    return (quantity * calculate_rate(fat, snf)).quantize(
        CENT, rounding=ROUND_HALF_UP
    )

def is_valid(quantity, fat, snf):
    return (
        quantity > 0
        and Decimal("2.0") <= fat <= Decimal("7.0")
        and Decimal("0.0") <= snf <= Decimal("12.0")
    )

def main():
    total = Decimal("0.00")
    farmer_id = input("Enter Farmer ID: ")

    for day in range(1, 11):
        print(f"\nDay {day}")
        try:
            quantity = Decimal(input("Enter litres: "))
            fat = Decimal(input("Enter fat: "))
            snf = Decimal(input("Enter SNF: "))
        except Exception:
            print("Invalid numerical input.")
            continue

        if not is_valid(quantity, fat, snf):
            print("Invalid record.")
            continue

        payment = calculate_payment(quantity, fat, snf)
        total += payment
        print(f"Payment: Rs.{payment:.2f}")

    print("\nFarmer ID:", farmer_id)
    print(f"Ten-day total: Rs.{total:.2f}")

if __name__ == "__main__":
    main()
