# TASK 5: User Input, Type Conversion and Validation

try:
    farmer_id = input("Enter Farmer ID: ")
    quantity = float(input("Enter milk quantity in litres: "))
    fat = float(input("Enter fat percentage: "))
    snf = float(input("Enter SNF percentage: "))

    if quantity <= 0:
        print("Invalid input: quantity must be greater than zero.")
    elif not (2.0 <= fat <= 7.0):
        print("Invalid input: fat must be between 2.0 and 7.0.")
    elif not (0.0 <= snf <= 12.0):
        print("Invalid input: SNF must be between 0 and 12.")
    else:
        fat_steps = (fat - 3.5) / 0.1
        snf_steps = (snf - 8.5) / 0.1
        rate = 30.00 + fat_steps * 0.40 + snf_steps * 0.30
        payment = quantity * rate

        print("Farmer ID:", farmer_id)
        print(f"Rate per litre: Rs.{rate:.2f}")
        print(f"Milk payment: Rs.{payment:.2f}")

except ValueError:
    print("Invalid numerical input. Please enter numbers correctly.")
