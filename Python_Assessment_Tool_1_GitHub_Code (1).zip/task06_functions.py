# TASK 6: Organise the Logic into Functions

BASE_RATE = 30.00
BASE_FAT = 3.5
BASE_SNF = 8.5
FAT_ADJUSTMENT = 0.40
SNF_ADJUSTMENT = 0.30

def rate_per_litre(fat, snf):
    fat_steps = (fat - BASE_FAT) / 0.1
    snf_steps = (snf - BASE_SNF) / 0.1
    return BASE_RATE + fat_steps * FAT_ADJUSTMENT + snf_steps * SNF_ADJUSTMENT

def payout(quantity, fat, snf):
    rate = rate_per_litre(fat, snf)
    return quantity * rate

def ten_day_total(payments):
    return sum(payments)

payments = []

for day in range(1, 11):
    print(f"\nDay {day}")
    quantity = float(input("Enter quantity: "))
    fat = float(input("Enter fat: "))
    snf = float(input("Enter SNF: "))

    if quantity <= 0 or not (2.0 <= fat <= 7.0) or not (0 <= snf <= 12):
        print("Invalid record. Payment not added.")
        continue

    payment = payout(quantity, fat, snf)
    payments.append(payment)
    print(f"Payment: Rs.{payment:.2f}")

print(f"\nTen-day total: Rs.{ten_day_total(payments):.2f}")
