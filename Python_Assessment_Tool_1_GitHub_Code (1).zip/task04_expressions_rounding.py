# TASK 4: Arithmetic Expressions, Operator Precedence and Rounding

import math

quantity = float(input("Enter milk quantity in litres: "))
fat = float(input("Enter fat percentage: "))
snf = float(input("Enter SNF percentage: "))

fat_steps = (fat - 3.5) / 0.1
snf_steps = (snf - 8.5) / 0.1

rate = 30.00 + (fat_steps * 0.40) + (snf_steps * 0.30)
payment = quantity * rate

print(f"Rate per litre: Rs.{rate:.2f}")
print(f"Payment: Rs.{payment:.2f}")

print("\nOperator precedence examples:")
print("2 + 3 * 4 =", 2 + 3 * 4)
print("-2 ** 2 =", -2 ** 2)
print("(-2) ** 2 =", (-2) ** 2)

number = 4.7
print("\nRounding examples for 4.7:")
print("round():", round(number))
print("int():", int(number))
print("math.floor():", math.floor(number))
