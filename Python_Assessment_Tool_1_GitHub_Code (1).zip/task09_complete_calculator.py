# TASK 9: Complete Calculator with Validation and Tests

from decimal import Decimal, ROUND_HALF_UP

BASE_RATE = Decimal("30.00")
BASE_FAT = Decimal("3.5")
BASE_SNF = Decimal("8.5")
FAT_ADJUSTMENT = Decimal("0.40")
SNF_ADJUSTMENT = Decimal("0.30")
CENT = Decimal("0.01")

def valid_input(quantity, fat, snf):
    return quantity > 0 and Decimal("2.0") <= fat <= Decimal("7.0") and Decimal("0") <= snf <= Decimal("12")

def rate_per_litre(fat, snf):
    fat_steps = (fat - BASE_FAT) / Decimal("0.1")
    snf_steps = (snf - BASE_SNF) / Decimal("0.1")
    return BASE_RATE + fat_steps * FAT_ADJUSTMENT + snf_steps * SNF_ADJUSTMENT

def payout(quantity, fat, snf):
    amount = quantity * rate_per_litre(fat, snf)
    return amount.quantize(CENT, rounding=ROUND_HALF_UP)

def ten_day_total(payments):
    return sum(payments, Decimal("0.00")).quantize(CENT, rounding=ROUND_HALF_UP)

def main():
    payments = []
    farmer_id = input("Enter Farmer ID: ")

    for day in range(1, 11):
        print(f"\nDay {day}")
        try:
            quantity = Decimal(input("Enter quantity: "))
            fat = Decimal(input("Enter fat: "))
            snf = Decimal(input("Enter SNF: "))
        except Exception:
            print("Invalid numerical input.")
            continue

        if not valid_input(quantity, fat, snf):
            print("Invalid input.")
            continue

        rate = rate_per_litre(fat, snf)
        payment = payout(quantity, fat, snf)
        payments.append(payment)
        print(f"Rate per litre: Rs.{rate:.2f}")
        print(f"Payment: Rs.{payment:.2f}")

    print("\nFarmer ID:", farmer_id)
    print(f"Total payment: Rs.{ten_day_total(payments):.2f}")

if __name__ == "__main__":
    main()
