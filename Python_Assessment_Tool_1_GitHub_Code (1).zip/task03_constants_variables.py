# TASK 3: Constants, Variables and Naming Conventions

BASE_RATE = 30.00
BASE_FAT = 3.5
BASE_SNF = 8.5

# Dynamic typing: the same variable can refer to different data types.
value = 10
print(value)
value = "Morning"
print(value)

# Multiple assignment and swapping
a, b = 10, 20
print("Before swapping:", a, b)
a, b = b, a
print("After swapping:", a, b)

# Use named constants in the milk rate calculation.
fat = float(input("Enter fat percentage: "))
snf = float(input("Enter SNF percentage: "))

fat_steps = (fat - BASE_FAT) / 0.1
snf_steps = (snf - BASE_SNF) / 0.1
rate = BASE_RATE + fat_steps * 0.40 + snf_steps * 0.30

print(f"Rate per litre: Rs.{rate:.2f}")
