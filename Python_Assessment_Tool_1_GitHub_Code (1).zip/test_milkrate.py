# Automated tests for milkrate.py

from milkrate import rate_per_litre, payout, valid_input, ten_day_total

def test_calculator():
    assert round(rate_per_litre(4.2, 8.7), 2) == 33.40
    assert round(payout(10, 3.5, 8.5), 2) == 300.00
    assert round(rate_per_litre(2.0, 8.5), 2) == 24.00
    assert round(rate_per_litre(7.0, 8.5), 2) == 44.00
    assert valid_input(10, 3.5, 8.5) is True
    assert valid_input(-5, 3.5, 8.5) is False
    assert valid_input(10, 1.9, 8.5) is False

    payments = [300.00, 283.90, 333.60, 150.00, 193.80]
    assert round(ten_day_total(payments), 2) == 1261.30

    print("All tests passed!")

if __name__ == "__main__":
    test_calculator()
