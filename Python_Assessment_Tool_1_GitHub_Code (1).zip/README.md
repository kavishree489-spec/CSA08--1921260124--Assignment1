# Python Programming Assessment Tool - 1 (CSA0820)

This repository contains beginner-friendly Python programs for the 12 tasks in the assessment.

## Files
- `task01_payment_calculator.py` to `task06_functions.py`: Tasks 1-6
- `milkrate.py` and `main_task07.py`: Task 7 module and main program
- `task08_algorithm_plan.py`: Task 8
- `task09_complete_calculator.py` and `test_milkrate.py`: Task 9 and automated tests
- `task10_float_decimal_benchmark.py`: Task 10
- `task11_recommended_design.py`: Task 11
- `task12_seasonal_bonus.py`: Task 12

## Run
Open a terminal in this folder and run a file, for example:

```bash
python task01_payment_calculator.py
```

For the module example, keep `milkrate.py` and `main_task07.py` in the same folder, then run:

```bash
python main_task07.py
```

Run the automated tests with:

```bash
python test_milkrate.py
```

## Important
The programs follow the constants, formulas, validation ranges and seasonal bonus rules written in the supplied assessment document. Confirm any rate rules with your faculty before final submission. Run the programs yourself and capture your own output screenshots as execution evidence.
