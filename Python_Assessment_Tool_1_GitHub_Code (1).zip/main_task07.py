# TASK 7: Main program that imports milkrate.py

import milkrate

payments = []

for day in range(1, 11):
    print(f"\nDay {day}")
    quantity = float(input("Enter quantity: "))
    fat = float(input("Enter fat: "))
    snf = float(input("Enter SNF: "))

    if milkrate.valid_input(quantity, fat, snf):
        payment = milkrate.payout(quantity, fat, snf)
        payments.append(payment)
        print(f"Payment: Rs.{payment:.2f}")
    else:
        print("Invalid input. Record skipped.")

print(f"\nTen-day total: Rs.{milkrate.ten_day_total(payments):.2f}")
