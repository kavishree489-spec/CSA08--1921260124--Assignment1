# TASK 8: Plan the Algorithm Before Coding
# This program follows the planned steps for one farmer's ten-day total.

BASE_RATE = 30.00

total_payment = 0.0

print("Milk Payment Calculator")
farmer_id = input("Enter Farmer ID: ")

for day in range(1, 11):
    print(f"\nDay {day}")
    quantity = float(input("Enter litres: "))
    fat = float(input("Enter fat percentage: "))
    snf = float(input("Enter SNF percentage: "))

    if quantity <= 0 or not (2.0 <= fat <= 7.0) or not (0 <= snf <= 12):
        print("Invalid input")
        continue

    fat_steps = (fat - 3.5) / 0.1
    snf_steps = (snf - 8.5) / 0.1
    rate = BASE_RATE + fat_steps * 0.40 + snf_steps * 0.30
    payment = quantity * rate
    total_payment += payment

    print(f"Rate per litre: Rs.{rate:.2f}")
    print(f"Payment: Rs.{payment:.2f}")

print("\nFarmer ID:", farmer_id)
print(f"Ten-day total: Rs.{total_payment:.2f}")

# Algorithm:
# 1. Start and read farmer ID.
# 2. Repeat for 10 days: read quantity, fat and SNF.
# 3. Validate the values.
# 4. Calculate rate and payment.
# 5. Add payment to running total.
# 6. Display the final total and stop.
