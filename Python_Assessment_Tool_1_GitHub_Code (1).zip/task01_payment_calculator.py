# TASK 1: Payment Calculator for a Village Milk Co-operative

BASE_RATE = 30.00
BASE_FAT = 3.5
BASE_SNF = 8.5
FAT_ADJUSTMENT = 0.40
SNF_ADJUSTMENT = 0.30

farmer_id = input("Enter Farmer ID: ")
total_payment = 0.0

for day in range(1, 11):
    print(f"\nDay {day}")
    quantity = float(input("Enter milk quantity (litres): "))
    fat = float(input("Enter fat percentage: "))
    snf = float(input("Enter SNF percentage: "))
    shift = input("Enter shift (Morning/Evening): ").strip().title()

    if quantity <= 0 or not (2.0 <= fat <= 7.0) or not (0 <= snf <= 12):
        print("Invalid input. This day's record is skipped.")
        continue

    if shift not in ("Morning", "Evening"):
        print("Invalid shift. This day's record is skipped.")
        continue

    fat_steps = (fat - BASE_FAT) / 0.1
    snf_steps = (snf - BASE_SNF) / 0.1
    rate = BASE_RATE + fat_steps * FAT_ADJUSTMENT + snf_steps * SNF_ADJUSTMENT
    payment = quantity * rate
    total_payment += payment

    print(f"Rate per litre: Rs.{rate:.2f}")
    print(f"{shift} payment: Rs.{payment:.2f}")

print("\nFarmer ID:", farmer_id)
print(f"Total payment for valid records: Rs.{total_payment:.2f}")
